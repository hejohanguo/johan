
.. _constrain.ValueSizeConstraint:

.. |Constraint| replace:: ValueSizeConstraint

Value size constraint
----------------------

.. autoclass:: pyasn1.type.constraint.ValueSizeConstraint(minimum, maximum)
   :members:

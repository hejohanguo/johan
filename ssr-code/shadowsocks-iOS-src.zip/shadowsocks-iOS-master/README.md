Shadowsocks for iOS and OSX
===========================
[![Build Status](https://travis-ci.org/shadowsocks/shadowsocks-iOS.svg?branch=master)](https://travis-ci.org/shadowsocks/shadowsocks-iOS)

Important note
--------------
This project has been forked from its original repository on August 22nd 2015,
shortly after fellow GitHub user @clowwindy has been asked by Beijing Central
Government to remove everything of the shadowsocks project.

Since then, this project has not been maintained by me or others, but many
forks happened to spread the code; each maintained with different quality and
purpose. However, as nobody oversees these projects, nobody should trust or rely
on these forked projects.

You can clearly see and proof that I forked the shadowsocks projects directly
from the original author, just before he had to close most of his projects.
Feel free to use his code for your own adaptions or to learn how your government
tries to protect you from dangerous ideas, like alternate beliefs, the disease
to speek freely (which infested the whole western hemisphere) or the joy of sex
and watching others having sex.

My thoughts and prayers extend to everyone fighting for a better future for
their society as well as to every victim of arbitrary province lords
incarcerating the workers class in the name of the workers class' party.

Never give up <3

__ Herzmut,
Berlin, Oct 16 '16


iOS
-----
[![iOS Icon](https://raw.github.com/shadowsocks/shadowsocks-iOS/master/ios_128.png)](https://github.com/shadowsocks/shadowsocks-iOS/wiki/Help)  
[iOS Version](https://github.com/shadowsocks/shadowsocks-iOS/wiki/Help)

OSX
-----
[![OSX Icon](https://raw.github.com/shadowsocks/shadowsocks-iOS/master/osx_128.png)](https://github.com/shadowsocks/shadowsocks-iOS/wiki/Shadowsocks-for-OSX-Help)  
[OSX Version](https://github.com/shadowsocks/shadowsocks-iOS/wiki/Shadowsocks-for-OSX-Help)

License
-------
The project is released under the terms of [GPLv3](https://raw.github.com/shadowsocks/shadowsocks-iOS/master/LICENSE).

Bugs and Issues
----------------

Please visit [issue tracker](https://github.com/shadowsocks/shadowsocks-iOS/issues?state=open)

Mailing list: http://groups.google.com/group/shadowsocks

Also see [troubleshooting](https://github.com/clowwindy/shadowsocks/wiki/Troubleshooting)
